// project imports
import Progress from './Progress';

// -----------------------|| LOADER ||-----------------------//

export default function Loader() {
  return <Progress isAnimating />;
}
