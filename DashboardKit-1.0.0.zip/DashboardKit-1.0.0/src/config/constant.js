// imports from project
export const BASE_TITLE = ' | DashboardKit React Bootstrap 5 Admin Template';

// -----------------------|| Application default Configuration ||-----------------------//

export const CONFIG = {
  collapseMenu: false // true for mini-menu
};
